﻿<?php
include 'connect.php';
define('UPLPATH', 'Slike/');
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Le Parisien</title>
</head>

<body>
    <header>
        <img src="Slike/LeParisienLogo.png" alt="Logo" class='logo'>
        <nav>
            <a href="index.php">HOME</a>
            <a href="kategorija.php?id=Parisien">PARISIEN</a>
            <a href="kategorija.php?id=Vivre Mieux">VIVRE</a>
            <a href="administracija.php">ADMINISTRACIJA</a>
        </nav>
    </header>

    <section class="artikli">
        <h3>_____<br>PARISIEN</h3>
        <div class="parisien">
            <?php
                $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='Parisien' LIMIT 3";
                $result = mysqli_query($dbc, $query);
                while($row = mysqli_fetch_array($result)) {
                    echo '<article>';
                    echo '<img src="' . UPLPATH . $row['slika'] . '">';
                    echo '<h2><a href="clanak.php?id='.$row['id'].'">';
                    echo $row['naslov'];
                    echo '</a></h2>';
                    echo '</article>';
                }
            ?>
        </div>

        <h3>_____<br>VIVRE MIEUX</h3>
        <div class="parisien">
            <?php
                $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='Vivre Mieux' LIMIT 3";
                $result = mysqli_query($dbc, $query);
                while($row = mysqli_fetch_array($result)) {
                    echo '<article>';
                    echo '<img src="' . UPLPATH . $row['slika'] . '">';
                    echo '<h2><a href="clanak.php?id='.$row['id'].'">';
                    echo $row['naslov'];
                    echo '</a></h2>';
                    echo '</article>';
                }
            ?>
        </div>
    </section>

    <footer>
        <p>Autor: Tomislav Nađ | Email: tomislav.nad@tvz.hr | 2025</p>
    </footer>
</body>
