﻿<?php
    include 'connect.php';
    define('UPLPATH', 'Slike/');

    $id = $_GET['id']; 
    $query = "SELECT * FROM vijesti WHERE id = ?";
    $stmt = mysqli_prepare($dbc, $query);
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
?>


<!DOCTYPE html>
<html lang="hr">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Le Parisien Clanak</title>
</head>

<body>
    <header>
        <img src="Slike/LeParisienLogo.png" alt="Logo" class='logo'>
        <nav>
            <a href="index.php">HOME</a>
            <a href="#">PARISIEN</a>
            <a href="#">VIVRE</a>
            <a href="administracija.php">ADMINISTRACIJA</a>
        </nav>
    </header>
    <section class="clanakSekcija">
        <h1 class="clanakNaslov"><?php echo $row['naslov']; ?></h1>
        <a><?php echo $row['datum']; ?></a>
        <img src="<?php echo UPLPATH . $row['slika']; ?>" alt="<?php echo $row['naslov']; ?>">
        <br>
        <h3 class="clanakNaslov2"><?php echo $row['sazetak']; ?></h3>
        <p class="clanakTekst">
            <?php echo($row['tekst']);?>
        </p>
    </section>
    <footer>
        <p>Autor: Tomislav Nađ | Email: tomislav.nad@tvz.hr | 2025</p>
    </footer>
</body>
