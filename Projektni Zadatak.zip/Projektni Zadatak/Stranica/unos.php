﻿<!DOCTYPE html>
<html lang="hr">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Le Parisien Unos</title>
</head>
<body>
    <header>
        <img src="Slike/LeParisienLogo.png" alt="Logo" class='logo'>
        <nav>
            <a href="index.php">HOME</a>
            <a href="#">PARISIEN</a>
            <a href="#">VIVRE</a>
            <a href="administracija.php">ADMINISTRACIJA</a>
        </nav>
    </header>

    <section>
        <h2>Unos članka</h2>
        <form action="skripta.php" method="POST" name="clanakForma" enctype="multipart/form-data">
            <div class="form-item">
                <label for="title">Naslov vijesti:</label>
                <div class="form-field">
                    <input type="text" name="title" id="title" class="form-field-textual" required>
                </div>
            </div>

            <div class="form-item">
                <label for="about">Kratki sadržaj vijesti (do 50 znakova):</label>
                <div class="form-field">
                    <textarea name="about" id="about" cols="30" rows="5" class="form-field-textual" maxlength="50" required></textarea>
                </div>
            </div>

            <div class="form-item">
                <label for="content">Sadržaj vijesti:</label>
                <div class="form-field">
                    <textarea name="content" id="content" cols="30" rows="10" class="form-field-textual" required></textarea>
                </div>
            </div>

            <div class="form-item">
                <label for="pphoto">Slika:</label>
                <div class="form-field">
                    <input type="file" accept="image/jpg,image/gif,image/png" id="pphoto" name="pphoto" required/>
                </div>
            </div>

            <div class="form-item">
                <label for="category">Kategorija vijesti:</label>
                <div class="form-field">
                    <select name="category" id="category" class="form-field-textual" required>
                        <option value="" disabled selected>Odaberi kategoriju</option>
                        <option value="Parisien">Parisien</option>
                        <option value="Vivre Mieux">Vivre Mieux</option>
                    </select>
                </div>
            </div>

            <div class="form-item">
                <label>
                    Spremiti u arhivu:
                    <div class="form-field">
                        <input type="checkbox" name="archive">
                    </div>
                </label>
            </div>

            <div class="form-item">
                <button type="reset" value="Poništi">Poništi</button>
                <button type="submit" value="Prihvati">Prihvati</button>
            </div>
        </form>

    </section>

</body>
 