﻿<?php
    include 'connect.php';

    $title = $_POST['title'];
    $about = $_POST['about'];
    $content = $_POST['content'];
    $pphoto = $_FILES['pphoto']['name'];
    $target_dir = 'Slike/'.$pphoto;
    move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);
    $category = $_POST['category'];
    if(isset($_POST['archive']))
    {
        $archive = 1;
    }
    else 
    {
        $archive = 0;
    }
    $date = date('d.m.Y.');

    $query = "INSERT INTO vijesti (naslov, datum, slika, sazetak, tekst, kategorija, arhiva) VALUES ('$title', '$date', '$pphoto', '$about', '$content', '$category', '$archive')";
    $stmt = mysqli_prepare($dbc, $query);

    $result = mysqli_query($dbc, $query) or die('Error querying databese.');
    mysqli_close($dbc)
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>Generirani Clanak - <?php echo $title; ?></title>
</head>
<body>
    <header>
        <img src="Slike/LeParisienLogo.png" alt="Logo" class='logo'>
        <nav>
            <a href="index.php">HOME</a>
            <a href="#">PARISIEN</a>
            <a href="#">VIVRE</a>
            <a href="administracija.php">ADMINISTRACIJA</a>
        </nav>
    </header>

    <section class="clanakSekcija">
        <h1 class="clanakNaslov"><?php echo $title; ?></h1>
        <p><?php echo date('d.m.Y.'); ?></p>
        <img src="Slike/<?php echo $pphoto; ?>" alt="Slika">  
        <h3 class="clanakNaslov2"><?php echo $about; ?></h3>
        <a class="clanakTekst">
            <?php echo($content);?>
        </a>
    </section>

    <footer>
        <p>Autor: Tomislav Nađ | Email: tomislav.nad@tvz.hr | 2025</p>
    </footer>
</body>
</html>