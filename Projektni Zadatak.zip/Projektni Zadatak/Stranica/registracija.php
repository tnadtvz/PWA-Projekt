﻿<?php
include 'connect.php';
$registriranKorisnik = false;
$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $username = $_POST['username'];
    $lozinka = $_POST['lozinka'];
    $lozinka2 = $_POST['lozinka2'];
    $razina = 0; 

    
    $sql = "SELECT korisnicko_ime FROM korisnik WHERE korisnicko_ime = ?";
    $stmt = mysqli_prepare($dbc, $sql);
    mysqli_stmt_bind_param($stmt, 's', $username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    $msg = '';
    if (mysqli_stmt_num_rows($stmt) > 0) 
    {
        $msg = 'Korisničko ime već postoji!';
    } 
    else 
    {
        if ($lozinka !== $lozinka2) 
        {
            $msg = 'Lozinke nisu iste!';
        } 
        else 
        {
            $hashed_password = password_hash($lozinka, CRYPT_BLOWFISH);

            $sql = "INSERT INTO korisnik (ime, prezime, korisnicko_ime, lozinka, razina) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($dbc, $sql);
            mysqli_stmt_bind_param($stmt, 'ssssi', $ime, $prezime, $username, $hashed_password, $razina);
            mysqli_stmt_execute($stmt);
            $registriranKorisnik = true;
            $msg = '';
        }
    }
    mysqli_close($dbc);
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Registracija</title>
    
</head>
<body>
    <header>
        <img src="Slike/LeParisienLogo.png" alt="Logo" class='logo'>
        <nav>
            <a href="index.php">HOME</a>
            <a href="kategorija.php?id=Parisien">PARISIEN</a>
            <a href="kategorija.php?id=Vivre Mieux">VIVRE</a>
            <a href="administracija.php">ADMINISTRACIJA</a>
        </nav>
    </header>

    <section role="main"">
            <h2>Registracija</h2>
            <form enctype="multipart/form-data" action="registracija.php" method="POST" name="registracijaForma">
                <div class="form-item">
                    <label for="ime">Ime:</label>
                    <br>
                    <input type="text" name="ime" id="ime" class="form-field-textual" required>
                </div>
                <div class="form-item">
                    <label for="prezime">Prezime:</label><br>
                    <input type="text" name="prezime" id="prezime" class="form-field-textual" required>
                </div>
                <div class="form-item">
                    <label for="username">Korisničko ime:</label><br>
                    <input type="text" name="username" id="username" class="form-field-textual" required>
                    <span id="porukaUsername" class="bojaPoruke">
                </div>
                <div class="form-item">
                    <label for="pass">Lozinka:</label><br>
                    <input type="password" name="lozinka" id="lozinka" class="form-field-textual" required>
                    <span id="porukaPass" class="bojaPoruke"></span>
                </div>
                <div class="form-item">
                    <label for="passRep">Ponovite lozinku:</label><br>
                    <input type="password" name="lozinka2" id="lozinka2" class="form-field-textual" required>
                    <span id="porukaPassRep" class="bojaPoruke"></span>
                </div>
                <div class="form-item">
                    <button type="submit" value="Prijava" id="slanje">Registriraj se</button>
                </div>
                <?php 
                if ($registriranKorisnik == true)
                {
                    $msg = 'Korisnik je uspješno registriran!';
                }
                echo $msg;
                ?>
            </form>
        
    </section>

    <footer>
        <p>Autor: Tomislav Nađ | Email: tomislav.nad@tvz.hr | 2025</p>
    </footer>
</body>
</html>