﻿<?php
include 'connect.php';
define('UPLPATH', 'Slike/');
$kategorijaId = $_GET['id'];
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Le Parisien - <?php echo $kategorijaId; ?></title>
</head>

<body>
    <header>
        <img src="Slike/LeParisienLogo.png" alt="Logo" class='logo'>
        <nav>
            <a href="index.php">HOME</a>
            <a href="kategorija.php?id=Parisien">PARISIEN</a>
            <a href="kategorija.php?id=Vivre Mieux">VIVRE</a>
            <a href="administracija.php">ADMINISTRACIJA</a>
        </nav>
    </header>
    <section class="artikli">
        <h3>_____<br><?php echo strtoupper($kategorijaId); ?></h3>
        <div class="parisien">
            <?php
                $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija=? ORDER BY id DESC";
                $stmt = mysqli_prepare($dbc, $query);
                mysqli_stmt_bind_param($stmt, 's', $kategorijaId);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);

                while($row = mysqli_fetch_array($result)) {
                    echo '<article>';
                    echo '<img src="' . UPLPATH . $row['slika'] . '">';
                    echo '<h2><a href="clanak.php?id='.$row['id'].'">';
                    echo $row['naslov'];
                    echo '</a></h2>';
                    echo '</article>';
                }
            ?>
        </div>
    </section>

    <footer>
        <p>Autor: Tomislav Nađ | Email: tomislav.nad@tvz.hr | 2025</p>
    </footer>
</body>
</html>
<?php mysqli_close($dbc); ?>