﻿<?php
include 'connect.php';
define('UPLPATH', 'Slike/');

$uspjesnaPrijava = false;

if (isset($_POST['prijava'])) 
{
    $prijavaImeKorisnika = $_POST['username'];
    $prijavaLozinkaKorisnika = $_POST['lozinka'];

    $sql = "SELECT korisnicko_ime, lozinka, razina FROM korisnik WHERE korisnicko_ime = ?";
    $stmt = mysqli_prepare($dbc, $sql);
    mysqli_stmt_bind_param($stmt, 's', $prijavaImeKorisnika);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, $levelKorisnika);
    mysqli_stmt_fetch($stmt);

   if (password_verify($_POST['lozinka'], $lozinkaKorisnika) && mysqli_stmt_num_rows($stmt) > 0) 
   {
        $uspjesnaPrijava = true;
        
        if ($levelKorisnika == 1) {
            $admin = true;
        }
        else {
            $admin = false;
        }
        $_SESSION['$username'] = $imeKorisnika;
        $_SESSION['$level'] = $levelKorisnika;
   }
   else {
        $uspjesnaPrijava = false;
   }
}

if(isset($_POST['delete']))
{
    $id = $_POST['id'];
    $query = "DELETE FROM vijesti WHERE id=$id";
    $result = mysqli_query($dbc, $query);
}

if(isset($_POST['update']))
{
    $picture = $_FILES['pphoto']['name'];
    $title = $_POST['title'];
    $about = $_POST['about'];
    $content = $_POST['content'];
    $category = $_POST['category'];
    if(isset($_POST['archive']))
    {
        $archive=1;
    }
    else
    {
        $archive=0;
    }
    $target_dir = 'Slike/'.$picture;
    move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);
    $id=$_POST['id'];
    $query = "UPDATE vijesti SET naslov='$title', sazetak='$about', tekst='$content',
    slika='$picture', kategorija='$category', arhiva='$archive' WHERE id=$id ";
    $result = mysqli_query($dbc, $query);
    
}
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Administracija</title>
</head>
<body>
    <header>
        <img src="Slike/LeParisienLogo.png" alt="Logo" class='logo'>
        <nav>
            <a href="index.php">HOME</a>
            <a href="kategorija.php?id=Parisien">PARISIEN</a>
            <a href="kategorija.php?id=Vivre Mieux">VIVRE</a>
            <a href="administracija.php">ADMINISTRACIJA</a>
        </nav>
    </header>

    <section class="artikli">
    <h2>Administracija vijesti</h2>
    <?php
    if (($uspjesnaPrijava == true && $admin == true) || (isset($_SESSION['$username'])) && $_SESSION['$level'] == 1) 
    {
        $query = "SELECT * FROM vijesti";
        $result = mysqli_query($dbc, $query);
        while($row = mysqli_fetch_array($result)) {
            echo '<form enctype="multipart/form-data" action="" method="POST">
                <input type="hidden" name="id" value="'.$row['id'].'">
                
                <div class="form-item">
                    <label for="title">Unesite nove vijesti </label>
                    <a href="unos.php">ovdje</a>
                </div>
                <br>
                <div class="form-item">
                    <label for="title">Naslov vijesti:</label>
                    <br>
                    <input type="text" name="title" class="form-field-textual" value="'.$row['naslov'].'">
                </div>
                <br>
                <div class="form-item">
                    <label for="about">Kratki sadržaj:</label>
                    <br>
                    <textarea name="about" cols="30" rows="5" class="form-field-textual">'.$row['sazetak'].'</textarea>
                </div>
                <br>
                <div class="form-item">
                    <label for="content">Sadržaj vijesti:</label>
                    <br>
                    <textarea name="content" cols="30" rows="10" class="form-field-textual">'.$row['tekst'].'</textarea>
                </div>
                <br>
                <div class="form-item">
                    <label for="pphoto">Slika:</label>
                    <input type="file" name="pphoto" class="form-field-textual">            
                    <br>
                    <img src="'.UPLPATH . $row['slika'].'">
                </div>
                <br>
                <div class="form-item">
                    <label for="category">Kategorija:</label>
                    <select name="category" class="form-field-textual">';
                        echo '<option value="Parisien" '.($row['kategorija'] == 'Parisien' ? 'selected' : '').'>Parisien</option>';
                        echo '<option value="Vivre Mieux" '.($row['kategorija'] == 'Vivre Mieux' ? 'selected' : '').'>Vivre Mieux</option>';
                    echo '</select>
                </div>
                <br>
                <div class="form-item">
                    <label>
                        Spremiti u arhivu:
                        <input type="checkbox" name="archive" '.($row['arhiva'] != 0 ? 'checked' : '').'>
                    </label>
                </div>
                <br>
                <div class="form-item">
                    <button type="submit" name="update" value="Prihvati">Izmijeni</button>
                    <button type="submit" name="delete" value="Izbriši">Izbriši</button>
                </div>
                <br><br><br>
            </form>';
        }
    }
    else if ($uspjesnaPrijava == true && $admin == false) {
        echo '<p>Bok ' . $imeKorisnika . '! Uspješno ste prijavljeni, ali niste administrator.</p>';
    }
    else if (isset($_SESSION['$username']) && $_SESSION['$level'] == 0) {
        echo '<p>Bok ' . $_SESSION['$username'] . '! Uspješno ste prijavljeni, ali niste administrator.</p>';
    } 
    else {
                ?>
                <h2>Prijava</h2>
                <form action="" method="POST">
                    <div class="form-item">
                        <label for="username">Korisničko ime:</label><br>
                        <input type="text" name="username" id="username" required>
                    </div>
                    <div class="form-item">
                        <label for="lozinka">Lozinka:</label><br>
                        <input type="password" name="lozinka" id="lozinka" required>
                    </div>
                    <div class="form-item">
                        <button type="submit" name="prijava" value="Prijava">Prijavi se</button>
                    </div>
                </form>
                <p>Nemate račun? <a href="registracija.php">Registrirajte se</a></p>
                <?php
            }
        ?>

    </section>
    
    <footer>
        <p>Autor: Tomislav Nađ | Email: tomislav.nad@tvz.hr | 2025</p>
    </footer>

</body>
</html>
<?php mysqli_close($dbc); ?>