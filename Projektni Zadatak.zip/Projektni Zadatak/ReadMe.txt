Cijeli folder staviti u: .../XAMPP/htdocs.

Potrebno je importati leparisien.sql kroz phpMyAdmin ili folder leparisien staviti u; .../XAMPP/MySQL/data.

Za pristup stranici u browser url pasteati: https://localhost/Projektni Zadatak/Stranica/index.php.

U bazi su kreirana dva korisnika: admin sa lozinkom admin i user sa lozinkom user.